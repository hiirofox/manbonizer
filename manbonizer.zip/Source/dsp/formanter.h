#pragma once

#include "fft.h"
#include "elliptic-blep.h"

class BlockResample
{
private:
	signalsmith::blep::EllipticBlep<float> blep;
public:
	void Process(const float* in, float* out, int numSamplesIn, int numSamplesOut, float stretch, float when)
	{
		blep.reset();
		float t = when - (int)when;

		int numOut = numSamplesIn * stretch;
		if (numOut > numSamplesOut)
		{
			numOut = numSamplesOut;
		}
		float k = 1.0 / stretch;
		int posIn = 0;
		for (int i = 0; i < numOut; ++i)
		{
			blep.step();
			t += k;
			while ((int)t)
			{
				t -= 1.0;
				float samplesInPast = t * stretch;
				float v = in[posIn++];
				blep.add(-v, 0, samplesInPast);
			}
			out[i] = blep.get();
		}
		for (int i = numOut; i < numSamplesOut; ++i)
		{
			out[i] = 0.0f;
		}
	}
};

class Formanter
{
private:
	constexpr static int MaxBufferInSize = 1024;//fft����Ҳ�������
	constexpr static int MaxBufferOutSize = MaxBufferInSize * 2;//fft����Ҳ�������
	constexpr static int MaxBlockSize = MaxBufferInSize / 2;
	float block[MaxBlockSize];
	float bufin[MaxBufferInSize];
	int posin = 0;
	float bufout[MaxBufferOutSize];
	int posout = 0;

	float pitch = 440.0 / 48000.0, formant = 1.0;


	float re1[MaxBufferInSize];
	float im1[MaxBufferInSize];
	float re2[MaxBufferInSize];
	float im2[MaxBufferInSize];
	int GetMaxCorrIndex()//��������(fft)
	{
		int len1 = MaxBufferInSize;
		for (int i = 0; i < len1; ++i) {
			//float w = window2[i];
			//re1[i] = copybuf[i] * w;
			re1[i] = bufin[i];
			im1[i] = 0.0f;
		}
		for (int i = 0; i < MaxBlockSize; ++i) {
			re2[i] = block[i];
			im2[i] = 0.0f;
		}
		for (int i = MaxBlockSize; i < MaxBufferInSize; ++i) {
			re2[i] = 0.0f;
			im2[i] = 0.0f;
		}
		fft_f32(re1, im1, MaxBufferInSize, 1);
		fft_f32(re2, im2, MaxBufferInSize, 1);
		for (int i = 0; i < MaxBufferInSize; ++i) {
			float re1v = re1[i];
			float im1v = im1[i];
			float re2v = re2[i];
			float im2v = -im2[i];//����ù���
			re1[i] = re1v * re2v - im1v * im2v;
			im1[i] = re1v * im2v + im1v * re2v;
		}
		fft_f32(re1, im1, MaxBufferInSize, -1);
		int index = 0;
		float max = -9999999999;
		for (int i = 0; i < MaxBlockSize; ++i) {
			float r = re1[i];
			if (r > max) {
				max = r;
				index = i;
			}
		}
		return index;
	}

	signalsmith::blep::EllipticBlep<float> blit;//���������޻���弤��
	BlockResample resampler;//���������ز���
	float step = 0.0;//step += pitch; (per sample)
	float re3[MaxBufferInSize * 2];
	float im3[MaxBufferInSize * 2];
	float re4[MaxBufferInSize * 2];
	float im4[MaxBufferInSize * 2];
	void Process()
	{
		int index = GetMaxCorrIndex();
		for (int i = 0; i < MaxBlockSize; ++i)
		{
			block[i] = bufin[i + index];
		}
		for (int i = 0; i < MaxBufferInSize; ++i)
		{
			blit.step();
			step += pitch;
			if (step >= 1.0)
			{
				step -= (int)step;
				blit.add(-1.0, 0, step / pitch);
			}
			//float w = 0.5 - 0.5 * cosf(2.0 * M_PI * i / MaxBufferInSize);//�Ӵ�
			float w = 1.0;
			re3[i] = blit.get() * w;
			im3[i] = 0;
		}
		for (int i = MaxBufferInSize; i < MaxBufferInSize * 2; ++i)
		{
			re3[i] = 0;
			im3[i] = 0;
		}
		for (int i = 0; i < MaxBlockSize; ++i)
		{
			float w = 0.5 - 0.5 * cosf(2.0 * M_PI * i / MaxBlockSize);//�Ӵ�
			//float w = 1.0;
			re4[i] = block[i] * w;
			im4[i] = 0;
		}
		for (int i = MaxBlockSize; i < MaxBufferInSize * 2; ++i)
		{
			re4[i] = 0;
			im4[i] = 0;
		}

		fft_f32(re3, im3, MaxBufferInSize * 2, 1);
		fft_f32(re4, im4, MaxBufferInSize * 2, 1);
		for (int i = 0; i < MaxBufferInSize * 2; ++i)
		{
			float re3v = re3[i];
			float im3v = im3[i];
			float re4v = re4[i];
			float im4v = im4[i];
			re4[i] = re3v * re4v - im3v * im4v;
			im4[i] = re3v * im4v + im3v * re4v;
		}
		fft_f32(re4, im4, MaxBufferInSize * 2, -1);

		for (int i = 0; i < MaxBufferInSize * 2; ++i)
		{
			re4[i] /= (float)(MaxBufferInSize * 2.0);
			//re4[i] *= 0.5 - 0.5 * cosf(2.0 * M_PI * i / (MaxBufferInSize * 2.0));//�Ӵ�
		}
		int pos = posout;
		for (int i = 0; i < MaxBufferInSize * 2; ++i)
		{
			bufout[pos++] += re4[i];
			if (pos >= MaxBufferOutSize)
			{
				pos = 0;
			}
		}
	}
public:
	Formanter()
	{
		memset(bufin, 0, sizeof(bufin));
		memset(bufout, 0, sizeof(bufout));
		memset(block, 0, sizeof(block));
		memset(re1, 0, sizeof(re1));
		memset(im1, 0, sizeof(im1));
		memset(re2, 0, sizeof(re2));
		memset(im2, 0, sizeof(im2));
		memset(re3, 0, sizeof(re3));
		memset(im3, 0, sizeof(im3));
		memset(re4, 0, sizeof(re4));
		memset(im4, 0, sizeof(im4));
	}
	void SetPitch(float freq)
	{
		pitch = freq / 48000.0f;
	}
	void SetFormant(float formant)
	{
		this->formant = formant;
	}
	void ProcessBlock(const float* in, float* out, int numSamples)
	{
		for (int i = 0; i < numSamples; ++i)
		{
			bufin[posin] = in[i];
			out[i] = bufout[posout];
			bufout[posout] = 0;

			posin++;
			if (posin >= MaxBufferInSize)
			{
				posin = 0;
				Process();
			}
			posout++;
			if (posout >= MaxBufferOutSize)
			{
				posout = 0;
			}
		}
	}
};